import hashlib
from urllib.parse import parse_qsl, quote_plus, unquote_plus, urlencode, urlsplit

from .config import PROXY_UA_TAG


def sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def parse_form_params(body: str) -> dict[str, str]:
    if not body:
        return {}
    return dict(parse_qsl(body, keep_blank_values=True))


def extract_form_param(body: str, name: str) -> str | None:
    return parse_form_params(body).get(name)


def extract_query_param(path: str, name: str) -> str | None:
    query = urlsplit(path).query
    if not query:
        return None
    return dict(parse_qsl(query, keep_blank_values=True)).get(name)


def extract_request_param(path: str, body: str, name: str) -> str | None:
    return extract_query_param(path, name) or extract_form_param(body, name)


def extract_action(path: str, body: str) -> str | None:
    return extract_request_param(path, body, "r")


def is_hardcore_request(path: str, body: str) -> bool:
    return extract_request_param(path, body, "h") == "1"


def replace_or_append_form_param(body: str, name: str, value: str) -> str:
    params = parse_qsl(body, keep_blank_values=True)
    encoded = quote_plus(value)
    replaced = False
    updated: list[str] = []

    for key, current_value in params:
        if key == name and not replaced:
            updated.append(f"{key}={encoded}")
            replaced = True
        elif key == name:
            continue
        else:
            updated.append(f"{key}={quote_plus(current_value)}")

    if not replaced:
        updated.append(f"{name}={encoded}")

    return "&".join(updated)


def build_form_body(params: dict[str, str]) -> str:
    return urlencode(params)


def proxy_user_agent(original: str) -> str:
    if PROXY_UA_TAG in original:
        return original
    return f"{original} {PROXY_UA_TAG}"


def canonical_reason_phrase(code: int) -> str:
    phrases = {
        200: "OK",
        400: "Bad Request",
        401: "Unauthorized",
        403: "Forbidden",
        404: "Not Found",
        405: "Method Not Allowed",
        413: "Payload Too Large",
        500: "Internal Server Error",
        501: "Not Implemented",
        503: "Service Unavailable",
    }
    return phrases.get(code, "Response")


def redact_query_tokens(value: str) -> str:
    parts = value.split("t=")
    if len(parts) < 2:
        return value

    rebuilt = [parts[0]]
    for segment in parts[1:]:
        token_tail = segment.split("&", 1)
        if len(token_tail) == 1:
            rebuilt.append("<token>")
        else:
            rebuilt.append(f"<token>&{token_tail[1]}")
    return "t=".join(rebuilt)


def redact_form_tokens(value: str) -> str:
    params = parse_qsl(value, keep_blank_values=True)
    redacted = [
        (key, "<token>" if key in {"t", "p"} else current) for key, current in params
    ]
    return urlencode(redacted)


def query_params_from_path(path: str) -> dict[str, str]:
    return dict(parse_qsl(urlsplit(path).query, keep_blank_values=True))


def decode_value(value: str) -> str:
    return unquote_plus(value)
